    <center>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main about-main">
            <!--tesimonial-->
            <div class="tesimonial">
                <h3>考生信息</h3>
                <div class="testi-info">
                    <div class="testi-left">
                        <img src="Home/images/3.jpg" alt="" width="100px" height="100px" />
                    </div>
                    <div class="testi-right">
                        <p><span>"</span> 风一样的女子 <span>"</span></p>
                        <a href="#">{{$info['stu_name']}}</a>
                    </div>
                    <div class="clearfix"> </div>
                </div>

            </div>
            <!--//tesimonial-->
        </div>
        </center>   