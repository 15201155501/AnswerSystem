<div class="sidebar-nav">
    <a href="#dashboard-menu" class="nav-header" data-toggle="collapse"><i class="icon-dashboard"></i>考试管理<i class="icon-chevron-up"></i></a>
    <ul id="dashboard-menu" class="nav nav-list collapse in">
        <li><a href="examList">每日必考</a></li>
        {{--<li ><a href="demoList">日常练习</a></li>--}}
        <li ><a href="historyExam">历史试卷</a></li>
    </ul>

    {{--<a href="#accounts-menu" class="nav-header" data-toggle="collapse"><i class="icon-briefcase"></i>工具下载<i class="icon-chevron-up"></i></a>--}}
    {{--<ul id="accounts-menu" class="nav nav-list collapse">--}}
        {{--<li ><a href="down">学习工具下载</a></li>--}}
    {{--</ul>--}}

    {{--<a href="#error-menu" class="nav-header collapsed" data-toggle="collapse"><i class="icon-exclamation-sign"></i>错题管理 <i class="icon-chevron-up"></i></a>--}}
    {{--<ul id="error-menu" class="nav nav-list collapse">--}}
        {{--<li ><a href="error">上传错题</a></li>--}}
        {{--<li ><a href="my_error">我的错题</a></li>--}}
    {{--</ul>--}}

    <a href="myself" class="nav-header" ><i class="icon-question-sign"></i>我的信息</a>
</div>