<?php

namespace App\Http\Controllers\Home;

use DB, Redirect, Input, Response, Request,Session;

use App\Http\Controllers\Controller;

//设置编码格式
header('content-type:text/html;charset=utf-8');
class AController extends Controller{

    //添加试卷
    public function index()
    {
    	echo 1; 
    }
}
