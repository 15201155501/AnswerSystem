<html>
<head>
    <meta http-equiv="Content-Language" mrc="zh-cn">
    <meta http-equiv="Content-Type" mrc="text/html; charset=utf8">
    <title>JavaScript在线考试系统</title>
</head>
<body>
<body>
<table width="75%" border="0" align="center">
    <tr>
        <td>
            <form name="quiz1" action ="checkExam"  method="post" >
                <hr>
                1. Internet上使用的网络协议是：__________
                <ol>
                    <input type="radio" name="Q1" value="*TCP/IP" onclick=this.value="*">
                    TCP/IP
                    <input type="radio" name="Q1" value="X.25" onclick=this.value="B">
                    X.25
                    <input type="radio" name="Q1" value="NetBEUI" onclick=this.value="C">
                    NetBEUI
                </ol>
                2. 我们通过__________长距离连接两台计算机使它们通讯。
                <ol>
                    <input type="radio" name="Q2" value="LAN" onClick=this.value="A">
                    LAN

                    <input type="radio" name="Q2" value="*WAN" onclick=this.value="*">
                    WAN

                    <input type="radio" name="Q2" value="WAIS" onClick=this.value="C">
                    WAIS
                </ol>
                3. HUB是指：__________
                <ol>
                    <input type="radio" name="Q3" value="网关" onClick=this.value="A">
                    网关

                    <input type="radio" name="Q3" value="网桥" onClick=this.value="B">
                    网桥

                    <input type="radio" name="Q3" value="路由器" onClick=this.value="C">
                    路由器

                    <input type="radio" name="Q3" value="*集线器" onClick=this.value="*">
                    集线器

                </ol>
                4. 56K MODEM的传输速度为：__________
                <ol>
                    <input type="radio" name="Q4" value="56Kbytes" onClick=this.value="A">
                    每秒传输56K bytes的数据。

                    <input type="radio" name="Q4" value="*56kbps" onClick=this.value="*">
                    每秒传输56k bits的数据。

                </ol>
                5. Gateway是指：__________
                <ol>
                    <input type="radio" name="Q5" value="*网关" onClick=this.value="*">
                    网关

                    <input type="radio" name="Q5" value="网桥" onClick=this.value="B">
                    网桥

                    <input type="radio" name="Q5" value="路由器" onClick=this.value="C">
                    路由器

                    <input type="radio" name="Q5" value="集线器" onClick=this.value="D">
                    集线器

                </ol>
                6. Http默认的端口是：__________
                <ol>
                    <input type="radio" name="Q6" value="8080" onClick=this.value="A">
                    8080

                    <input type="radio" name="Q6" value="*80" onClick=this.value="*">
                    80

                    <input type="radio" name="Q6" value="25" onClick=this.value="C">
                    25

                </ol>
                7. JavaScript是一种类似于C++的语言，比较难掌握：__________
                <ol>
                    <input type="radio" name="Q7" value="True" onClick=this.value="T">
                    True

                    <input type="radio" name="Q7" value="*False" onClick=this.value="*">
                    False

                </ol>
                8. JAVA是 __________ 公司的产品：
                <ol>
                    <input type="radio" name="Q8" value="Microsoft" onClick=this.value="A">
                    Microsoft

                    <input type="radio" name="Q8" value="Novell" onClick=this.value="B">
                    Novell

                    <input type="radio" name="Q8" value="*SUN" onClick=this.value="*">
                    SUN

                </ol>
                9. CGI通过__________收集用户填写的表单信息：
                <ol>
                    <input type="radio" name="Q9" value="Form" onClick=this.value="A">
                    Form

                    <input type="radio" name="Q9" value="*环境变量" onClick=this.value="*">
                    环境变量

                    <input type="radio" name="Q9" value="javascripts脚本" onClick=this.value="C">
                    javascripts脚本

                </ol>
                10. 服务器响应"404 error"的含义是： __________
                <ol>
                    <input type="radio" name="Q10" value="*文件不存在" onClick=this.value="*">
                    文件不存在
                    <input type="radio" name="Q10" value="Server error" onClick=this.value="B">
                    服务器错误
                    <input type="radio" name="Q10" value="Client error" onClick=this.value="C">
                    浏览器错误

                </ol>
                11. 服务器响应"404 error"的含义是： __________
                <ol>
                    <input type="checkbox" name="Q11[]" value="测试数据1" onClick=this.value="A">
                    测试数据1
                    <input type="checkbox" name="Q11[]" value="测试数据2" onClick=this.value="B">
                    测试数据2
                    <input type="checkbox" name="Q11[]" value="测试数据3" onClick=this.value="*">
                    测试数据3
                    <input type="checkbox" name="Q11[]" value="测试数据4" onClick=this.value="*">
                    测试数据4
                </ol>
                12. 服务器响应"404 error"的含义是： __________
                <ol>
                    <input type="checkbox" name="Q12[]" value="测试数据1" onClick=this.value="*">
                    测试数据1
                    <input type="checkbox" name="Q12[]" value="测试数据2" onClick=this.value="*">
                    测试数据2
                    <input type="checkbox" name="Q12[]" value="测试数据3" onClick=this.value="*">
                    测试数据3
                    <input type="checkbox" name="Q12[]" value="测试数据4" onClick=this.value="*">
                    测试数据4
                </ol>
                <hr>
                <input type="submit" value="提交试卷" class="pt9">
                <input type="reset" name="reset" value="重新测试" class="pt9">
            </form>
</body>
</html>